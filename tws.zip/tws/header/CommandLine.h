extern char *System_Argument(char *Flag, char *Name, int argc, char *argv[]);
extern char *SystemArgument(char *Flag, char *Name, int argc, char *argv[]);

extern int System_Flag(char *Flag, int argc, char *argv[]);
extern int SystemFlag(char *Flag, int argc, char *argv[]);
