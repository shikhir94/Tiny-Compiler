extern void FatalError(void);
extern void IncrementErrorCount(int n);

extern int ErrorCount;
