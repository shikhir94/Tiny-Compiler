/*******************************************************************
          Copyright (C) 1986 by Manuel E. Bermudez
          Translated to C - 1991
********************************************************************/

#include <stdio.h>
#include <header/CommandLine.h>
#include <header/Open_File.h>
#include <header/Table.h>
#include <header/Text.h>
#include <header/Error.h>
#include <header/String_Input.h>
#include <header/Tree.h>
#include <header/Code.h>
#include <header/CodeGenerator.h>  
#define LeftMode 0
#define RightMode 1

    /*  ABSTRACT MACHINE OPERATIONS  */
#define    NOP          1   /* 'NOP'       */
#define    HALTOP       2   /* 'HALT'      */      
#define    LITOP        3   /* 'LIT'       */
#define    LLVOP        4   /* 'LLV'       */
#define    LGVOP        5   /* 'LGV'       */
#define    SLVOP        6   /* 'SLV'       */
#define    SGVOP        7   /* 'SGV'       */
#define    LLAOP        8   /* 'LLA'       */
#define    LGAOP        9   /* 'LGA'       */
#define    UOPOP       10   /* 'UOP'       */
#define    BOPOP       11   /* 'BOP'       */     
#define    POPOP       12   /* 'POP'       */  
#define    DUPOP       13   /* 'DUP'       */
#define    SWAPOP      14   /* 'SWAP'      */
#define    CALLOP      15   /* 'CALL'      */
#define    RTNOP       16   /* 'RTN'       */
#define    GOTOOP      17   /* 'GOTO'      */
#define    CONDOP      18   /* 'COND'      */
#define    CODEOP      19   /* 'CODE'      */
#define    SOSOP       20   /* 'SOS'       */
#define    LIMITOP     21   /* 'LIMIT'     */

    /* ABSTRACT MACHINE OPERANDS */

         /* UNARY OPERANDS */
#define    UNOT        22   /* 'UNOT'     */
#define    UNEG        23   /* 'UNEG'     */
#define    USUCC       24   /* 'USUCC'    */
#define    UPRED       25   /* 'UPRED'    */
         /* BINARY OPERANDS */
#define    BAND        26   /* 'BAND'     */
#define    BOR         27   /* 'BOR'      */
#define    BPLUS       28   /* 'BPLUS'    */
#define    BMINUS      29   /* 'BMINUS'   */
#define    BMULT       30   /* 'BMULT'    */
#define    BDIV        31   /* 'BDIV'     */
#define    BEXP        32   /* 'BEXP'     */
#define    BMOD        33   /* 'BMOD'     */
#define    BEQ         34   /* 'BEQ'      */
#define    BNE         35   /* 'BNE'      */
#define    BLE         36   /* 'BLE'      */
#define    BGE         37   /* 'BGE'      */
#define    BLT         38   /* 'BLT'      */
#define    BGT         39   /* 'BGT'      */
         /* OS SERVICE CALL OPERANDS */
#define    TRACEX      40   /* 'TRACEX'   */
#define    DUMPMEM     41   /* 'DUMPMEM'  */
#define    OSINPUT     42   /* 'INPUT'    */
#define    OSINPUTC    43   /* 'INPUT'    */
#define    OSOUTPUT    44   /* 'OUTPUT'   */
#define    OSOUTPUTC   45   /* 'OUTPUT'   */
#define    OSOUTPUTL   46   /* 'OUTPUTL'  */
#define    OSEOF       47   /* 'EOF'      */

         /* TREE NODE NAMES */
#define    ProgramNode  48   /* 'program'  */
#define    TypesNode    49   /* 'types'    */
#define    TypeNode     50   /* 'type'     */
#define    DclnsNode    51   /* 'dclns'    */
#define    VarNode     52   /* 'dcln'     */
#define    IntegerTNode 53   /* 'integer'  */
#define    BooleanTNode 54   /* 'boolean'  */
#define    BlockNode    55   /* 'block'    */
#define    AssignNode   56   /* 'assign'   */
#define    OutputNode   57   /* 'output'   */ 
#define    IfNode       58   /* 'if'       */
#define    WhileNode    59   /* 'while'    */
#define    NullNode     60   /* '<null>'   */
#define    LENode       61   /* '<='       */
#define    GTENode      62   /* '>='       */
#define    NEQNode      63   /* '<>'       */
#define    LTNode       64   /* '<'       */
#define    GTNode       65   /* '>'       */
#define    EQNode       66   /* '='       */
#define    ExpNode      67   /* '**'       */
#define    PlusNode     68   /* '+'        */
#define    MinusNode    69   /* '-'        */
#define    MultNode     70   /* '*'        */
#define    DivNode      71   /* '/'        */
#define    AndNode      72   /* 'and'        */
#define    ModNode      73   /* 'mod'        */
#define    OrNode       74   /* 'or'        */
#define    TrueNode     75   /* 'true'      */
#define    FalseNode    76   /* 'false' */
#define    NotNode      77   /* 'not'        */
#define    ReadNode     78   /* 'read'     */
#define    IntegerNode  79   /* '<integer>'*/
#define    IdentifierNode 80 /* '<identifier>'*/
#define    EofNode        81 /* 'eof' */
#define	   RepeatNode     82 /* 'repeat'*/
#define    LoopNode       83 /* 'loop' */
#define    ToNode         84 /* 'Upto'*/
#define    ExitNode       85 /* 'exit' */
#define    SwapNode       86 /* 'swap' */
#define    CaseNode       87
#define    CaseClauseNode 88
#define    DotDotNode     89
#define    DownToNode     90
#define    LitNode        91
#define    ConstsNode	  92
#define	   ConstNode	  93
#define    CharNode	  94
#define    SuccNode	  95
#define	   PredNode	  96
#define    ChrNode	  97
#define    OrdNode	  98
#define    LineNode       99
#define    SubProgsNode   100
#define    FunctionNode   101
#define    ParamsNode     102
#define    CallNode       103
#define    ReturnNode     104
#define    ProcedureNode  105
 
#define    NumberOfNodes 105 /* '<identifier>'*/
typedef int Mode;

FILE *CodeFile;
char *CodeFileName;
Clabel HaltLabel;
typedef TreeNode UserType;
UserType TypeInteger, TypeBoolean, TypeChar;
TreeNode temp;

char *mach_op[] = 
    {"NOP","HALT","LIT","LLV","LGV","SLV","SGV","LLA","LGA",
     "UOP","BOP","POP","DUP","SWAP","CALL","RTN","GOTO","COND",
     "CODE","SOS","LIMIT","UNOT","UNEG","USUCC","UPRED","BAND",
     "BOR","BPLUS","BMINUS","BMULT","BDIV","BEXP","BMOD","BEQ",
     "BNE","BLE","BGE","BLT","BGT","TRACEX","DUMPMEM","INPUT",
     "INPUTC","OUTPUT","OUTPUTC","OUTPUTL","EOF"};

/****************************************************************** 
   add new node names to the end of the array, keeping in strict order
   as defined above, then adjust the j loop control variable in
   InitializeNodeNames(). 
*******************************************************************/
char *node_name[] =
    {"program","types","type","dclns","var","integer",
     "boolean","block","assign","output","if","while",
     "<null>","<=",">=","<>","<",">","=","**","+","-",
      "*","/","and","mod","or","true","false","not","read",
     "<integer>","<identifier>","eof","repeat","loop","to",
     "exit",":=:","case","<case_clause>","..","downto",
     "lit","consts","const","<char>","succ","pred","chr","ord","<string>","subprogs","function","params","call","return","procedure"};


void CodeGenerate(int argc, char *argv[])
{
   int NumberTrees;

   InitializeCodeGenerator(argc,argv);
   Tree_File = Open_File("_TREE", "r"); 
   NumberTrees = Read_Trees();
   fclose (Tree_File);
                     
   temp = Child(RootOfTree(1),2);
   TypeBoolean = Child(temp,1);
   TypeInteger = Child(temp,2);
   TypeChar = Child(temp,3);

   HaltLabel = ProcessNode (RootOfTree(1), NoLabel);
   CodeGen0 (HALTOP, HaltLabel); 

   CodeFile = Open_File (CodeFileName, "w");
   DumpCode (CodeFile);
   fclose(CodeFile); 

   if (TraceSpecified)
      fclose (TraceFile);

/****************************************************************** 
  enable this code to write out the tree after the code generator
  has run.  It will show the new decorations made with MakeAddress().
*******************************************************************/


   Tree_File = fopen("_TREE", "w");  
   Write_Trees();
   fclose (Tree_File);                   
}


void InitializeCodeGenerator(int argc,char *argv[])
{
   InitializeMachineOperations();
   InitializeNodeNames();
   FrameSize = 0;
   CurrentProcLevel = 0;
   LabelCount = 0;
   CodeFileName = System_Argument("-code", "_CODE", argc, argv); 
}


void InitializeMachineOperations(void)
{
   int i,j;

   for (i=0, j=1; i < 47; i++, j++)
      String_Array_To_String_Constant (mach_op[i],j);
}



void InitializeNodeNames(void)
{
   int i,j;

   for (i=0, j=48; j <= NumberOfNodes; i++, j++)
      String_Array_To_String_Constant (node_name[i],j);
}



String MakeStringOf(int Number)
{
   Stack Temp;

   Temp = AllocateStack (50);
   ResetBufferInTextTable();
   if (Number == 0)
      AdvanceOnCharacter ('0');
   else
   {
      while (Number > 0)
      {
         Push (Temp,(Number % 10) + 48);
         Number /= 10;
      }

      while ( !(IsEmpty (Temp)))
         AdvanceOnCharacter ((char)(Pop(Temp)));
   }   
   return (ConvertStringInBuffer()); 
}  



void Reference(TreeNode T, Mode M, Clabel L)
{
   int Addr,OFFSET;
   String  Op;

   Addr = Decoration(Decoration(T));
   OFFSET = FrameDisplacement (Addr) ;
   switch (M)
   {
      case LeftMode  :  DecrementFrameSize();
                        if (ProcLevel (Addr) == 0) 
                           Op = SGVOP;
                        else
                           Op = SLVOP;
	                break;
      case RightMode :  IncrementFrameSize();
                        if (ProcLevel (Addr) == 0) 
                           Op = LGVOP;
          	        else
                           Op = LLVOP;
                        break;
   }
   CodeGen1 (Op,MakeStringOf(OFFSET),L);
}



int NKids (TreeNode T)
{
   return (Rank(T));
}


String ModeOf(TreeNode T){
	TreeNode T1,T2;
	String name;

	T1 = Decoration(T);
	T2 = Child(T1,1);
	name = NodeName(Decoration(T2));
	/*printf("%d",name);
	printf("%d",TypeNode);
	printf("%d",VarNode);*/
	
	return name;
}


void Expression (TreeNode T, Clabel CurrLabel)
{
   int Kid;
   Clabel Label1, Label2;
   String s,s1;
   char c;
   
   if (TraceSpecified)
   {
      fprintf (TraceFile, "<<< CODE GENERATOR >>> Processing Node ");
      Write_String (TraceFile, NodeName (T) );
      fprintf (TraceFile, " , Label is  ");
      Write_String (TraceFile, CurrLabel);
      fprintf (TraceFile, "\n");
   }

   switch (NodeName(T))
   {
      case LENode :
      case GTENode :
      case NEQNode :
      case LTNode :
      case GTNode :
      case EQNode :

         Expression ( Child(T,1) , CurrLabel);
         Expression ( Child(T,2) , NoLabel);
     	if(NodeName(T) == LENode)
         CodeGen1 (BOPOP, BLE, NoLabel);
	else if(NodeName(T) == GTENode)
	 CodeGen1 (BOPOP, BGE, NoLabel);
	else if(NodeName(T) == NEQNode)
	 CodeGen1 (BOPOP, BNE, NoLabel);
	else if(NodeName(T) == LTNode)
	 CodeGen1 (BOPOP, BLT, NoLabel);
	else if(NodeName(T) == GTNode)
	 CodeGen1 (BOPOP, BGT, NoLabel);
	else 
	 CodeGen1 (BOPOP, BEQ, NoLabel);
         DecrementFrameSize();
         break;

      case MultNode :
      case DivNode :
         Expression ( Child(T,1) , CurrLabel);
         Expression ( Child(T,2) , NoLabel);
         if (NodeName(T) == MultNode)
            CodeGen1 (BOPOP, BMULT, NoLabel);
         else
            CodeGen1 (BOPOP, BDIV, NoLabel);
         DecrementFrameSize();
         break;

      case AndNode :
      case OrNode :
         Expression ( Child(T,1) , CurrLabel);
         Expression ( Child(T,2) , NoLabel);
        if(NodeName(T) == AndNode)
            CodeGen1 (BOPOP, BAND, NoLabel);
	else
	    CodeGen1 (BOPOP, BOR, NoLabel);
  	 DecrementFrameSize();
         break;

      case ExpNode :
      case ModNode :
         Expression ( Child(T,1) , CurrLabel);
         Expression ( Child(T,2) , NoLabel);
        if(NodeName(T) == ExpNode)
            CodeGen1 (BOPOP, BEXP, NoLabel);
  	else
	    CodeGen1 (BOPOP, BMOD, NoLabel);
	 DecrementFrameSize();
         break;

      case MinusNode :
         Expression ( Child(T,1) , CurrLabel);
         if (Rank(T) == 2)
         {
            Expression ( Child(T,2) , NoLabel);
            CodeGen1 (BOPOP, BMINUS, NoLabel);
            DecrementFrameSize();
         }
         else
            CodeGen1 (UOPOP, UNEG, NoLabel);
         break;

      case PlusNode :
         Expression ( Child(T,1) , CurrLabel);
         if (Rank(T) == 2)
         {
            Expression ( Child(T,2) , NoLabel);
            CodeGen1 (BOPOP, BPLUS, NoLabel);
            DecrementFrameSize();
         }
                   
         break;



	case NotNode :
	  Expression(Child(T,1),CurrLabel);
	  CodeGen1 (UOPOP, UNOT, NoLabel);
	  break;

      case EofNode :
         CodeGen1 (SOSOP, OSEOF, CurrLabel);
         IncrementFrameSize();
         break;

      case LineNode:
	 s = NodeName(Child(T,1));
         Kid = 3;
	if(Character(s,2) != '\"'){
	if (Character(s,2) != '\\'){
	CodeGen1 (LITOP, MakeStringOf(Character(s,2)), CurrLabel);
	IncrementFrameSize();
	CodeGen1 (SOSOP, OSOUTPUTC, NoLabel);
	DecrementFrameSize();
	}	
	else{
	CodeGen1 (LITOP, MakeStringOf(9), CurrLabel);
	IncrementFrameSize();
	CodeGen1 (SOSOP, OSOUTPUTC, NoLabel);
	DecrementFrameSize();
	Kid++;
	}

	 while(Character(s,Kid)!='\"')
	 {
		if (Character(s,Kid) != '\\'){
		CodeGen1 (LITOP, MakeStringOf(Character(s,Kid)), NoLabel);
	 	IncrementFrameSize();
		CodeGen1 (SOSOP, OSOUTPUTC, NoLabel);
		DecrementFrameSize();
		}
		else{
		CodeGen1 (LITOP, MakeStringOf(9), NoLabel);
		IncrementFrameSize();
		CodeGen1 (SOSOP, OSOUTPUTC, NoLabel);
		DecrementFrameSize();
		Kid++;
		}
	 Kid++;
	 }
	}
	 break;
     
      case CallNode :
	 CodeGen1(LITOP, MakeStringOf(0), CurrLabel);
	 IncrementFrameSize();
	 Label2 = Decoration(Decoration(Child(Decoration(Child(T,1)),1)));
	 if (NKids(T) > 1){
	 	for (Kid = 2; Kid <= NKids(T); Kid++)
			Expression(Child(T,Kid), NoLabel);
	 }
	 CodeGen1(CODEOP, Label2, NoLabel);
	 if (NKids(T) > 1){
         	for (Kid = 2; Kid <= NKids(T); Kid++)
			DecrementFrameSize();
	 }
	 CodeGen1(CALLOP, MakeStringOf(FrameSize - 1), NoLabel);
      break;


      case IntegerNode :
         CodeGen1 (LITOP, NodeName (Child(T,1)), CurrLabel);
         IncrementFrameSize();
         break;

      case CharNode :
	 s = NodeName(Child(T,1));
	 c = Character(s,2);
	 CodeGen1 (LITOP, MakeStringOf(c), CurrLabel);
	 IncrementFrameSize();
	 break;

      case TrueNode :
          CodeGen1 (LITOP, MakeStringOf(1), CurrLabel);
         IncrementFrameSize();
         break;

      case FalseNode :
         CodeGen1 (LITOP, MakeStringOf(0), CurrLabel);
         IncrementFrameSize();
         break;


      case IdentifierNode :
         if(ModeOf(T) == ConstNode || ModeOf(T) == LitNode){
		CodeGen1 (LITOP, Decoration(Decoration(T)), CurrLabel);
		IncrementFrameSize();
	 }
	 else
	 	Reference (T,RightMode,CurrLabel);
         break;

      case OrdNode:
      case ChrNode:
	 Expression(Child(T,1),CurrLabel);
	 break;

      case SuccNode:
      case PredNode:
	 Expression(Child(T,1),CurrLabel);
	 if(NodeName(T) == SuccNode){
		CodeGen1 (UOPOP, USUCC, NoLabel);
	 }
	 else{
		CodeGen1 (UOPOP , UPRED , NoLabel);
	}
	break;      	 

      default :
         ReportTreeErrorAt(T);
         printf ("<<< CODE GENERATOR >>> : UNKNOWN NODE NAME ");
         Write_String (stdout,NodeName(T));
         printf ("\n");

   } /* end switch */
} /* end Expression */



Clabel ProcessNode (TreeNode T, Clabel CurrLabel)
{
   int Kid, Num, BlockDone = 0;
   String s;
   char c;
   TreeNode Type1;
   Clabel Label1, Label2, Label3,LR,LabelL,LabelE;

   if (TraceSpecified)
   {
      fprintf (TraceFile, "<<< CODE GENERATOR >>> Processing Node ");
      Write_String (TraceFile, NodeName (T) );
      fprintf (TraceFile, " , Label is  ");
      Write_String (TraceFile, CurrLabel);
      fprintf (TraceFile, "\n");
   }

   switch (NodeName(T))
   {
      case ProgramNode :
	 for (Kid = 2; NodeName(Child(T,Kid)) != BlockNode; Kid++){
	 	if (NodeName(Child(T,Kid)) == SubProgsNode){
	 		Label1 = MakeLabel();
	 		CodeGen1(GOTOOP, Label1, CurrLabel);
	 		LabelL = ProcessNode(Child(T,Kid), CurrLabel);
	 		CurrLabel = ProcessNode(Child(T,Kid+1), Label1);
			BlockDone = 1;
	 	}
	 	else 
			CurrLabel = ProcessNode(Child(T,Kid), CurrLabel);
	 }
	 if (BlockDone == 0) 
		CurrLabel = ProcessNode(Child(T,Kid), CurrLabel);
	 return (CurrLabel);

      case SubProgsNode :
         for (Kid = 1; Kid <= NKids(T); Kid++)
            CurrLabel = ProcessNode (Child(T,Kid), CurrLabel);
         return (CurrLabel);
 
      case FunctionNode :
	 OpenFrame();
	 Decorate (Child(T,1), MakeAddress());
         IncrementFrameSize();
	 Label2 = MakeLabel();
	 Decorate(T,Label2);
	 Kid = 0;
	 if (NodeName(Child(T,2)) == ParamsNode){
	 	CurrLabel = ProcessNode(Child(T,2), CurrLabel);
		Kid = 4;
	 }
	 else{
		Kid = 3;
	 }
	 for ( ; NodeName(Child(T,Kid)) != BlockNode; Kid++){
	 	if (NodeName(Child(T,Kid)) == DclnsNode){
	 		CurrLabel = ProcessNode(Child(T,Kid), Label2);
	 		CurrLabel = ProcessNode(Child(T,Kid+1), CurrLabel);
			BlockDone = 1;
	 	}
	 	else
			CurrLabel = ProcessNode(Child(T,Kid), CurrLabel);
	 }
		/*printf("in outside func blockdone %d",BlockDone);*/
	 if (BlockDone == 0){
		/*printf("in in func blockdone %d",BlockDone);*/
		CurrLabel = ProcessNode(Child(T,Kid), Label2);
	 } 
		
	 CodeGen1 (LLVOP, MakeStringOf(0), CurrLabel);
	 CodeGen1 (RTNOP, MakeStringOf(1), NoLabel);
	 CloseFrame();
	 return(NoLabel);
      
     case ProcedureNode :
	 OpenFrame();
	 Label2 = MakeLabel();
	 Decorate(T,Label2);
	 Kid = 0;
	 if (NodeName(Child(T,2)) == ParamsNode){
	 	CurrLabel = ProcessNode(Child(T,2), CurrLabel);
		Kid = 3;
	 }
	 else 
		Kid = 2;
	 for ( ; NodeName(Child(T,Kid)) != BlockNode; Kid++){
	 	if (NodeName(Child(T,Kid)) == DclnsNode){
	 		CurrLabel = ProcessNode(Child(T,Kid), Label2);
	 		CurrLabel = ProcessNode(Child(T,Kid+1), CurrLabel);
			BlockDone = 1;
	 	}
	 	else
			CurrLabel = ProcessNode(Child(T,Kid), CurrLabel);
	 }
		/*printf("in outside func blockdone %d",BlockDone);*/
	 if (BlockDone == 0){
		/*printf("in in func blockdone %d",BlockDone);*/
		CurrLabel = ProcessNode(Child(T,Kid), Label2);
	 } 
		
	 CodeGen1 (RTNOP, MakeStringOf(0), CurrLabel);
	 CloseFrame();
	 return(NoLabel);

      case CallNode :
	 Label2 = Decoration(Decoration(Child(Decoration(Child(T,1)),1)));
	  	for (Kid = 2; Kid <= NKids(T); Kid++){
			if (Kid == 2)
				Expression(Child(T,Kid), CurrLabel);
			else
				Expression(Child(T,Kid), NoLabel);
	 	}
	 if (NKids(T) > 1)
	 	CodeGen1(CODEOP, Label2, NoLabel);
	 else
		CodeGen1(CODEOP, Label2, CurrLabel);
	 for (Kid = 2; Kid <= NKids(T); Kid++)
		DecrementFrameSize();
	 CodeGen1(CALLOP, MakeStringOf(FrameSize), NoLabel);
      return (NoLabel);


      case ParamsNode :
	 for (Kid = 1; Kid <= NKids(T); Kid++)
		CurrLabel = ProcessNode(Child(T,Kid), CurrLabel);
	 return(CurrLabel);
	 

      case ReturnNode :
	 if (NKids(T) >= 1){
	 	Expression(Child(T,1), CurrLabel);
	 	CodeGen1(RTNOP, MakeStringOf(1), NoLabel);
	 	DecrementFrameSize();
		return (NoLabel);
	 }
	 return(CurrLabel);

      case TypesNode :
         for (Kid = 1; Kid <= NKids(T); Kid++)
            CurrLabel = ProcessNode (Child(T,Kid), CurrLabel);
         return (CurrLabel);

      case TypeNode :
	 if (Rank(T) == 2)
		if(NodeName(Child(T,2)) == LitNode)
			CurrLabel = ProcessNode(Child(T,2),CurrLabel);
         return (CurrLabel);

      case DclnsNode :
         for (Kid = 1; Kid <= NKids(T); Kid++)
            CurrLabel = ProcessNode (Child(T,Kid), CurrLabel);
         if (NKids(T) > 0)
            return (NoLabel);
         else
            return (CurrLabel);


      case ConstsNode :
         for (Kid = 1; Kid <= NKids(T); Kid++)
            CurrLabel = ProcessNode (Child(T,Kid), CurrLabel);
         if (NKids(T) > 0)
            return (NoLabel);
         else
            return (CurrLabel);

      case ReadNode :

	 if (Decoration(Child(Child(T,1),1)) == TypeInteger)
         	CodeGen1 (SOSOP, OSINPUT, CurrLabel);
         else
		CodeGen1 (SOSOP, OSINPUTC, CurrLabel);
	  IncrementFrameSize();
	  Reference (Child(T,1), LeftMode, NoLabel);
	for(Kid =2; Kid <= NKids(T); Kid++){
	 if (Decoration(Child(Child(T,Kid),1)) == TypeInteger)
         	CodeGen1 (SOSOP, OSINPUT, NoLabel);
         else
		CodeGen1 (SOSOP, OSINPUTC, NoLabel);
	 IncrementFrameSize();
         Reference (Child(T,Kid), LeftMode, NoLabel);
	 }
	 return(NoLabel);
         

      case LitNode:
	  for (Kid = 0;Kid < NKids(T); Kid++)
	  {
	    
            Decorate ( Child(T,Kid+1), MakeStringOf(Kid));

          }
         return (NoLabel);                 

 

      case ConstNode:
	if(NodeName(Child(T,2)) == IntegerNode){
	 	Decorate(Child(T,1),NodeName(Child(Child(T,2),1)));
        }
	else if(NodeName(Child(T,2)) == CharNode){
	
	 s = NodeName(Child(Child(T,2),1));
	 
	c = Character(s,2);
	
	 Decorate(Child(T,1),MakeStringOf(c));
	}
	else{
	    Type1 = Decoration(Child(T,2));
	    s = Decoration(Type1);
	    if (Character(s,1) == '\'')
	    	Decorate(Child(T,1), MakeStringOf(Character(s,2)));
	    else
		Decorate(Child(T,1), s);	        
	}
	return (CurrLabel); 	


      case VarNode :
	 if (NodeName(Decoration(T)) == ParamsNode){ /* Decorated in constrainer */
		/*printf("im in if");*/
		for (Kid = 1; Kid < NKids(T); Kid++)
         	{	
            		Num = MakeAddress();
            		Decorate ( Child(T,Kid), Num);
            		IncrementFrameSize();
         	}

	 }
	 else{
		/*printf("im in else");*/
         	for (Kid = 1; Kid < NKids(T); Kid++)
         	{	
            		if (Kid != 1)
               			CodeGen1 (LITOP,MakeStringOf(0),NoLabel);
            		else
               			CodeGen1 (LITOP,MakeStringOf(0),CurrLabel);
            		Num = MakeAddress();
            		Decorate ( Child(T,Kid), Num);
            		IncrementFrameSize();
         	}
	 }
         return (NoLabel);                 

      case BlockNode :
         for (Kid = 1; Kid <= NKids(T); Kid++)
            CurrLabel = ProcessNode (Child(T,Kid), CurrLabel);
         return (CurrLabel); 


      case AssignNode :
         Expression (Child(T,2), CurrLabel);
         Reference (Child(T,1), LeftMode, NoLabel);
         return (NoLabel);

      case SwapNode :
         Expression (Child(T,2), CurrLabel);
        /*/Expression (Child(T,2), NoLabel);
         //CodeGen0 (SWAPOP, NoLabel);*/
         Reference (Child(T,1),RightMode,NoLabel);
	 Reference (Child(T,2),RightMode,NoLabel);
	 Reference (Child(T,1),LeftMode,NoLabel);
	 Reference (Child(T,2),LeftMode,NoLabel);

	return (NoLabel);



      case OutputNode :
          if (NodeName(Child(Child(T,1),1)) == LineNode)
	   Expression (Child(Child(T,1),1), CurrLabel);
          else{
	   Expression (Child(Child(T,1),1), CurrLabel);
          
	    if (Decoration(Child(T,1)) == TypeInteger )
            	CodeGen1 (SOSOP, OSOUTPUT, NoLabel);
	    else
		CodeGen1 (SOSOP, OSOUTPUTC, NoLabel);
	    DecrementFrameSize();
          }
         for (Kid = 2; Kid <= NKids(T); Kid++)
         {
	   Expression (Child(Child(T,Kid),1), NoLabel);
	    
           if (NodeName(Child(Child(T,Kid),1)) != LineNode)
		{
	    if (Decoration(Child(T,Kid)) == TypeInteger )
            	CodeGen1 (SOSOP, OSOUTPUT, NoLabel);
	    else
		CodeGen1 (SOSOP, OSOUTPUTC, NoLabel);
            DecrementFrameSize();
         }}
         CodeGen1 (SOSOP, OSOUTPUTL, NoLabel);
         return (NoLabel);


      case IfNode :
         Expression (Child(T,1), CurrLabel);
         Label1 = MakeLabel();
         Label2 = MakeLabel();
         Label3 = MakeLabel();
         CodeGen2 (CONDOP,Label1,Label2, NoLabel);
         DecrementFrameSize();
         CodeGen1 (GOTOOP, Label3, ProcessNode (Child(T,2), Label1) );
         if (Rank(T) == 3)
            CodeGen0 (NOP, ProcessNode (Child(T,3),Label2));
         else
            CodeGen0 (NOP, Label2);
         return (Label3);                


      case WhileNode :
         if (CurrLabel == NoLabel) 
            Label1 = MakeLabel();
         else 
            Label1 = CurrLabel;
         Label2 = MakeLabel();
         Label3 = MakeLabel();
         Expression (Child(T,1), Label1);
         CodeGen2 (CONDOP, Label2, Label3, NoLabel);
         DecrementFrameSize();
         CodeGen1 (GOTOOP, Label1, ProcessNode (Child(T,2), Label2) );
         return (Label3);

      case RepeatNode :
         if (CurrLabel == NoLabel) 
            Label1 = MakeLabel();
         else 
            Label1 = CurrLabel;
         Label2 = MakeLabel();
	 LR = MakeLabel();
	 LR = Label1;
	 for (Kid = 1; Kid <= NKids(T)-1; Kid++)
            Label1 = ProcessNode (Child(T,Kid), Label1);
         Expression (Child(T,NKids(T)),Label1);
         CodeGen2 (CONDOP, Label2, LR, NoLabel);
         DecrementFrameSize();
       
         return (Label2);

	case LoopNode :
	   if (CurrLabel == NoLabel) 
            Label2 = MakeLabel();
         else 
            Label2 = CurrLabel;
         Label1 = MakeLabel();
	 LR = MakeLabel();
	 Decorate(T,Label1);
	 LR = Label2;
	 for (Kid = 1; Kid <= NKids(T); Kid++)
            Label2 = ProcessNode (Child(T,Kid), Label2);
       
         CodeGen1 (GOTOOP, LR,  Label2);
       
         return (Label1);

	case ExitNode :
	 Label1 = Decoration(Decoration(T));
	 CodeGen1 (GOTOOP,Label1,CurrLabel);

	return (NoLabel);

	case DownToNode :
	case ToNode :
	 Expression(Child(T,3),CurrLabel);
	 Expression(Child(T,2),NoLabel);
	 Reference(Child(T,1),LeftMode,NoLabel);
         Label1 = MakeLabel();
	 CodeGen0 (DUPOP, Label1);
	 IncrementFrameSize();
	 Reference(Child(T,1),RightMode,NoLabel);
         if(NodeName(T) == ToNode)
	 	CodeGen1 (BOPOP,BGE,NoLabel);
	 else
		CodeGen1 (BOPOP,BLE,NoLabel);
	 DecrementFrameSize();
	 Label2 = MakeLabel();
	 Label3 = MakeLabel();
         LR = MakeLabel();
	 CodeGen2 (CONDOP, Label2, Label3, NoLabel);
	 DecrementFrameSize();
	 LR = ProcessNode(Child(T,4),Label2);
	 Reference(Child(T,1),RightMode,LR);
	if(NodeName(T) == ToNode)
	 CodeGen1 (UOPOP, USUCC, NoLabel);
	else
 	 CodeGen1 (UOPOP, UPRED, NoLabel);
 	 
	 Reference(Child(T,1),LeftMode,NoLabel);
 	 CodeGen1 (GOTOOP, Label1, NoLabel);
 	 CodeGen1 (POPOP, MakeStringOf(1), Label3);
	 DecrementFrameSize();
	 CodeGen1 (LITOP, MakeStringOf(0), NoLabel);
	 IncrementFrameSize();
	 Reference (Child(T,1), LeftMode,NoLabel);

       
         return (NoLabel);

	case CaseNode :
	  LabelE = MakeLabel();
	  LR = MakeLabel();

	  Expression(Child(T,1),CurrLabel);

	
		LR = ProcessNode(Child(T,2),NoLabel);
                Label2 = MakeLabel();
		Label1 = MakeLabel();
		CodeGen2 (CONDOP, Label1, Label2, LR);
	        DecrementFrameSize();
		CodeGen1 (POPOP, MakeStringOf(1), Label1);
		DecrementFrameSize();
		LR = ProcessNode (Child(Child(T,2),2), NoLabel);
		CodeGen1 (GOTOOP, LabelE, LR);

	  if(NKids(Child(T,NKids(T))) == 1)
	  {  
	  for (Kid = 3;Kid < NKids(T);Kid++)  /* this  loop runs if otherwise exits*/
	  {
		
		LR = ProcessNode(Child(T,Kid),Label2);
                Label2 = MakeLabel();
		Label1 = MakeLabel();
		CodeGen2 (CONDOP, Label1, Label2, LR);
		DecrementFrameSize();
		CodeGen1 (POPOP, MakeStringOf(1), Label1);
		DecrementFrameSize();
		LR = ProcessNode (Child(Child(T,Kid),2), NoLabel);
		CodeGen1 (GOTOOP, LabelE, LR);
	  }
	  	CodeGen1 (POPOP, MakeStringOf(1), Label2);
		DecrementFrameSize();
		LR = ProcessNode (Child(Child(T,NKids(T)),1),NoLabel);
		CodeGen0 (NOP,LR);
		IncrementFrameSize();
	  }
	  else{
	 for (Kid = 3;Kid <= NKids(T);Kid++)  /* this loop runs if otherwise dont exits*/
	  {
		LR = ProcessNode(Child(T,Kid),Label2);
		Label2 = MakeLabel();
		Label1 = MakeLabel();
		CodeGen2 (CONDOP, Label1, Label2, LR);
		DecrementFrameSize();
		CodeGen1 (POPOP, MakeStringOf(1), Label1);
		DecrementFrameSize();
		LR = ProcessNode (Child(Child(T,Kid),2), NoLabel);
		CodeGen1 (GOTOOP, LabelE,LR);
		IncrementFrameSize();
	  }
	  	CodeGen1 (POPOP, MakeStringOf(1), Label2);
	        DecrementFrameSize();
		IncrementFrameSize();
	  }
	  return (LabelE);

       case CaseClauseNode :
	  if (NKids(Child(T,1)) == 2){
		
		CodeGen0 (DUPOP,CurrLabel);
		IncrementFrameSize();
		CodeGen0 (DUPOP,NoLabel);
		IncrementFrameSize();
		/*CodeGen1 (LITOP,NodeName(Child(Child(Child(T,1),1),1)),NoLabel);*/
	        Expression(Child(Child(T,1),1),NoLabel);
		CodeGen1 (BOPOP,BGE,NoLabel);
		DecrementFrameSize();
		CodeGen0 (SWAPOP,NoLabel);
               	/*CodeGen1 (LITOP,NodeName(Child(Child(Child(T,1),2),1)),NoLabel);*/
		Expression(Child(Child(T,1),2), NoLabel);
		CodeGen1 (BOPOP,BLE,NoLabel);
		DecrementFrameSize();
		CodeGen1 (BOPOP,BAND,NoLabel);
         	DecrementFrameSize();
	}
	else{
		CodeGen0 (DUPOP,CurrLabel);
		IncrementFrameSize();
	        Expression(Child(T,1),NoLabel);
		CodeGen1 (BOPOP,BEQ,NoLabel);
		DecrementFrameSize();
	}
	return(NoLabel);
		


       case NullNode : return(CurrLabel);

 
      default :
              ReportTreeErrorAt(T);
              printf ("<<< CODE GENERATOR >>> : UNKNOWN NODE NAME ");
              Write_String (stdout,NodeName(T));
              printf ("\n");

   } /* end switch */
}   /* end ProcessNode */
