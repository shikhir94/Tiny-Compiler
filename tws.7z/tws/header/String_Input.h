/**************************************************************************
       STRING INPUT MODULE HEADER  -   String.Input.h
***************************************************************************/
extern String Convert_InputLineTo_String(FILE *InFile);
/*    extern ReadAll_StringsFrom();     */
extern void String_Array_To_String_Constant (char *Name, String Constant);
extern void StringArrayToStringConstant (char *Name, String Constant);
extern String String_Array_To_String(char *Name);


