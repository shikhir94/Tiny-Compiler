#include "Trees.h"
#include "DLists.h"

typedef struct {
    int line;
    int column;
    char *string;
    int makenode;
} TOKEN_INFO;  
